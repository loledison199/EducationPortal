# required imports
# the sqlite3 library allows us to communicate with the sqlite database
import sqlite3
# we are adding the import 'g' which will be used for the database
from flask import Flask, session, redirect, url_for, escape, request, render_template, g
from sqlalchemy.orm import sessionmaker
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql import text


app = Flask(__name__)
app.secret_key='abbas'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)


# setup the default route
# this is the page the site will load by default (i.e. like the home page)
@app.route('/')
def root():
	# judge whether the user is in system
	if 'username' in session:
		sql = "select username, user_type from users where username == '{}'".format(session['username'])
		result = db.engine.execute(text(sql))
		# if the user is, then for loop the database to see what is the user's indentity
		for user in result:
			# turn to the instructor_index or student_index fit to the user's indentity
			if user['user_type'] == 'instructor':
				return render_template('instructor_index.html')
			elif user['user_type'] == 'student':
				return render_template('student_index.html')
	else:
		return redirect(url_for('authen_user'))
	

@app.route('/login', methods=['GET', 'POST'])
def authen_user():
	if request.method == 'POST':
		# find out the user in database
		users = "select * from users"
		results = db.engine.execute(text(users))
		# for loop the whole database to find which username and password matches
		for user in results:
			if user['username'] == request.form['username']:
				if user['password'] == request.form['password']:
					session['username'] = request.form['username']
					# if find the user is student then turn to the student home pase
					if user['user_type'] == 'student':
						return render_template('student_index.html')
					# if find the user is instructor then turn to the instructor home pase
					else:
						return render_template('instructor_index.html')
		return render_template('login.html', login=False)
	else:
		return render_template('login.html')

@app.route('/logout')
def logout():
	# delete the username so that the user will left
	session.pop('username', None)
	return redirect(url_for('authen_user'))

@app.route('/marks', methods=['GET', 'POST'])
def marks():
	# check the user name
	if 'username' not in session:
		return redirect(url_for('authen_user'))
	# enter into this user's text file of database to find the user's type
	user_type = "select user_type from users where username == '{}'".format(session['username'])
	types = db.engine.execute(text(user_type))
	# for loop the types and get the matches file
	for type in types:
		# if the user is an instructor then get all the stuent's grade to him
		if type['user_type'] == 'instructor':
			marks = "select * from student_grades"
			result = db.engine.execute(text(marks))
			return render_template('instructor_marks.html', grades=result)
		# if the user is a student then get his own grade to him
		else:
			mark = "select * from student_grades where username == '{}'".format(session['username'])
			student_mark = db.engine.execute(text(mark))
			return render_template('student_marks.html', grade=student_mark)

@app.route('/remarks', methods=['POST', 'GET'])
def remarks():
	if 'username' not in session:
		return redirect(url_for('authen_user'))
	# get the user type
	user_type = "select user_type from users where username == '{}'".format(session['username'])
	types = db.engine.execute(text(user_type))
	for type in types:
		# if it's a instructor then get all the student's remark to him from the datebase
		if type['user_type'] == 'instructor':
			remarks = "select * from remark_requests"
			result = db.engine.execute(text(remarks))
			return render_template('instructor_remarks.html', grades=result)
		# if it's a student then put all the poseted user's remark reason in the databse
		else:
			# when the student post his remark then find his username and put his username
			# and reason in the database together
			if request.method =='POST':
				username = session['username']
				r = request.form['reason']
				insertSQL = "insert into remark_requests (username, reason) values ('{}', '{}')".format(session['username'], r)
				a = db.engine.execute(text(insertSQL))
			return render_template('student_remark.html')

if __name__=="__main__":
	app.run(debug=True)
